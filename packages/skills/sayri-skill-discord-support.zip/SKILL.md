---
name: "sayri-skill-discord-support"
title: "Discord Voice & Support Agent"
description: "Autonomous AI support subagent for Discord servers with zero host terminal execution permissions."
version: "1.0.0"
author: "jaimegh-es"
sandbox_level: "LEVEL_0_NO_EXEC"
allowed_tools: ["discord_send_message"]
---

# Discord Support Skill
Autonomous support subagent.
