---
name: "Web Search Tool"
description: "Searches the web via DuckDuckGo and Wikipedia APIs"
sandbox_level: "LEVEL_1_READONLY"
version: "1.2.0"
---
# Web Search Tool Instructions
Use DuckDuckGo search API to retrieve public documentation.